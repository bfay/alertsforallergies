		</div><!-- End Main row -->
		
		<footer id="content-info" class="footer" role="contentinfo">
			<!--<div class="row">
				<?php dynamic_sidebar("Footer"); ?>
			</div>-->
	<div class="row">
	<div class="row panel">
				<div class="four columns text-center paypal inner-footer right-border"><img src="http://images.alertsforallergies.com/paypal_verified.png" alt="Paypal Verified">
				</div>
				<div class="four columns inner-footer right-border fancy-font"><h4><span style="text-decoration: underline;"><span style="text-align: center;">Products</span></span></h4>
<ul>
<li><a href="http://www.alertsforallergies.com/products/signs/">Signs</a></li>
<li><a href="http://www.alertsforallergies.com/products/tattoos/">Tattoos</a></li>
<li><a href="http://www.alertsforallergies.com/products/products/stickers/">Stickers</a></li>
<li><a href="http://www.alertsforallergies.com/products/lunch-bags/">Lunch Bags</a></li>
<li><a href="http://www.alertsforallergies.com/products/chef-cards/">Chef Cards</a></li>
</ul>
				</div>
			
				<div class="four columns inner-footer right-border fancy-font"><h4><span style="text-decoration: underline;"><span style="text-align: center;">Our Company</span></span></h4>
				<ul>
<li><a href="http://www.alertsforallergies.com/about/">About</a></li>
<li><a href="http://www.alertsforallergies.com/contact/">Contact</a></li>
<li><a href="http://www.peanutfreezone.com/terms/">Terms &amp; Conditions</a></li>
<li><a href="http://www.peanutfreezone.com/privacy/">Privacy Policy</a></li>
				</ul>
				</div>
				
				<div class="four columns inner-footer"><img src="http://www.peanutfreezone.com/wp-content/uploads/2012/06/Medical-Disclaimer-Title.png" alt="Medical Disclaimer" title="Medical-Disclaimer-Title" width="220" height="35" class="disclaimer" /></br><p class="fancy-font">Please note: Any information posted on this site is not intended and should not replace professional medical advice. Discuss all questions of a medical nature with your doctor or allergist.</p>
				</div>
	</div>
		
			
							
			
			
		
			
	</div><!-- Container End -->
	</footer>
	
	
	<!-- Prompt IE 6 users to install Chrome Frame. Remove this if you want to support IE 6.
	     chromium.org/developers/how-tos/chrome-frame-getting-started -->
	<!--[if lt IE 7]>
		<script defer src="//ajax.googleapis.com/ajax/libs/chrome-frame/1.0.3/CFInstall.min.js"></script>
		<script defer>window.attachEvent('onload',function(){CFInstall.check({mode:'overlay'})})</script>
	<![endif]-->
	
	<?php wp_footer(); ?>
	
	<div class="copyright text-center">
					</br>
					&copy; 2010-<?php echo date('Y'); ?> &nbsp-&nbsp
					Alerts for Allergies &nbsp-&nbsp
					All rights reserved &nbsp-&nbsp
					
					Designed by <a href="http://www.eighthloop.com" rel="nofollow" title="Eighthloop Framework">Eighthloop</a>
				</div>

</body>
</html>