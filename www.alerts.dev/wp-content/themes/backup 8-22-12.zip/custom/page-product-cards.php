<?php
/*
Template Name: Product Cards
*/
get_header(); ?>


		</div><!--end main-->

	
			
		
<?php get_footer(); ?>