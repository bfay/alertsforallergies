<?php
/*
Template Name: Product Page
*/
get_header(); ?>

		<!-- Row for main content area -->
		<div id="product-page" class="product-container" role="main">
		

		</div><!--end main-->

	
			
		
<?php get_footer(); ?>