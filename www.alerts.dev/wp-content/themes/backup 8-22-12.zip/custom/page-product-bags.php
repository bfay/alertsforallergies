<?php
/*
Template Name: Product Bags
*/
get_header(); ?>


		</div><!--end main-->

	
			
		
<?php get_footer(); ?>